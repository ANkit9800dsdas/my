const fs = require('fs')
const chalk = require('chalk')
//git test by Sam    huh
global.autoTyping = false //auto tying in gc (true to on, false to off)
global.autoreadpmngc = false //auto reading in gc and pm (true to on, false to off)
global.autoReadGc = true //auto reading in gc (true to on, false to off)
global.autoReadAll = false // auto reading in all pchat gc and status (true to on, false to off)
global.autoRecord = false //auto recording (true to on, false to off)
global.available = true //auto available (true to on, false to off)
global.thum = fs.readFileSync("./ZeroTwoMedia/image3.jpg") //ur thumb pic
global.log0 = fs.readFileSync("./ZeroTwoMedia/image3.jpg") //ur logo pic
global.err4r = fs.readFileSync("./ZeroTwoMedia/image3.jpg") //ur error pic
global.thumb = fs.readFileSync("./ZeroTwoMedia/image3.jpg")

global.ytname = "YT: Zero Two Multi Device"
global.location = "Sultanpur, Uttar Pradesh, India"
global.botscript = "https://github.com/SamPandey001/Zero-Two-Md"
global.antitags = true
global.rkyt = []
global.banUser = []
global.banchat = []
global.ntilink = []
global.ntwame = []
global.nttoxic = []
global.ntnsfw = []
global.ntvirtex = []
global.wlcm = []
global.gcrevoke = []
global.apikey = process.env.HEROKU_API_KEY_NEW || 'NO-API'
global.appname = process.env.HEROKUAPP_NAME || 'NO-Name'
var _0x1a32e8=_0x41cc;function _0x41cc(_0x40a8d6,_0x3701e2){var _0x2635b7=_0x2635();return _0x41cc=function(_0x41cc3a,_0x231162){_0x41cc3a=_0x41cc3a-0x1ee;var _0x1a7446=_0x2635b7[_0x41cc3a];return _0x1a7446;},_0x41cc(_0x40a8d6,_0x3701e2);}(function(_0x1ecbf2,_0x7bdf04){var _0x5aa09a=_0x41cc,_0x3df619=_0x1ecbf2();while(!![]){try{var _0x5cc6d3=-parseInt(_0x5aa09a(0x1f7))/0x1*(-parseInt(_0x5aa09a(0x208))/0x2)+-parseInt(_0x5aa09a(0x20a))/0x3+parseInt(_0x5aa09a(0x1fe))/0x4+-parseInt(_0x5aa09a(0x213))/0x5*(parseInt(_0x5aa09a(0x214))/0x6)+-parseInt(_0x5aa09a(0x1ef))/0x7+parseInt(_0x5aa09a(0x1f4))/0x8*(-parseInt(_0x5aa09a(0x1f1))/0x9)+-parseInt(_0x5aa09a(0x207))/0xa*(-parseInt(_0x5aa09a(0x211))/0xb);if(_0x5cc6d3===_0x7bdf04)break;else _0x3df619['push'](_0x3df619['shift']());}catch(_0x2d5d82){_0x3df619['push'](_0x3df619['shift']());}}}(_0x2635,0xb11de),global[_0x1a32e8(0x203)]={'zenz':_0x1a32e8(0x1f3),'amel':_0x1a32e8(0x1fa),'bx':_0x1a32e8(0x201),'hardianto':_0x1a32e8(0x20e),'jonaz':_0x1a32e8(0x1fc),'neoxr':_0x1a32e8(0x212),'xteam':_0x1a32e8(0x1ee),'nzcha':_0x1a32e8(0x206),'bg':_0x1a32e8(0x204),'fdci':_0x1a32e8(0x1f6),'rey':'https://server-api-rey.herokuapp.com','dzx':_0x1a32e8(0x1f9),'bsbt':_0x1a32e8(0x1fb),'zahir':_0x1a32e8(0x1f5),'zeks':_0x1a32e8(0x210),'zekais':_0x1a32e8(0x1f2),'hardianto':_0x1a32e8(0x202),'pencarikode':_0x1a32e8(0x20f),'erdwepe':_0x1a32e8(0x209),'lolhuman':'https://api.lolhuman.xyz','LeysCoder':_0x1a32e8(0x200)},global[_0x1a32e8(0x1ff)]={'https://zenzapis.xyz':_0x1a32e8(0x20d),'https://melcanz.com':_0x1a32e8(0x205),'https://hardianto.xyz':'hardianto','https://api.xteam.xyz':'Dawnfrostkey','https://zahirr-web.herokuapp.com':_0x1a32e8(0x20b),'https://bsbt-api-rest.herokuapp.com':'benniismael','https://server-api-rey.herokuapp.com':_0x1a32e8(0x20c),'https://api.zeks.xyz':'apivinz','https://hardianto-chan.herokuapp.com':'hardianto','https://pencarikode.xyz':_0x1a32e8(0x1f0),'https://leyscoders-api.herokuapp.com':_0x1a32e8(0x1fd),'https://zekais-api.herokuapp.com':_0x1a32e8(0x1f8),'https://api.lolhuman.xyz':'pelitbetsihluwh'});function _0x2635(){var _0x254d9e=['APIKeys','https://leyscoders-api.herokuapp.com','https://bx-hunter.herokuapp.com','https://hardianto-chan.herokuapp.com','APIs','http://bochil.ddns.net','elaina','http://nzcha-apii.herokuapp.com','23240MWEtdw','2mgCnbp','https://erdwpe-api.herokuapp.com','4057560PxhLYH','zahirgans','apirey','4ad2c1556c','https://hardianto.xyz','https://pencarikode.xyz','https://api.zeks.xyz','12881pMnlwi','https://neoxr-api.herokuapp.com','5455EMlIaQ','618qCuUOC','https://api.xteam.xyz','6307182QLPFhR','pais','5333697XNqdoy','http://zekais-api.herokuapp.com','https://zenzapis.xyz','16SRFgTg','https://zahirr-web.herokuapp.com','https://api.fdci.se','544763FimhMg','zekais','https://api.dhamzxploit.my.id','https://melcanz.com','https://bsbt-api-rest.herokuapp.com','https://jonaz-api-v2.herokuapp.com','dappakntlll','4041952CDMDxA'];_0x2635=function(){return _0x254d9e;};return _0x2635();}
//═══════[modification]════════\\
global.owner = process.env.owner || ['919628516236','916307151530','918953092716' , '919330953026' , '918101187835'] //owner number, u can put multiple owner number, within quotations and seperated by comma.
global.pemilik = ['919628516236' , '918101187835'] //another owner number
global.premium = ['919628516236' , '918101187835'] //premium number
global.pengguna = '𝐙𝐞𝐫𝐨 𝐓𝐰𝐨 𝐌𝐝' //username
global.mongodb = process.env.MONGODB_URI || "Enter-MongoURI-HERE"

global.port = process.env.PORT || 5000
global.botnma = process.env.botnma || '𝐙𝐞𝐫𝐨 𝐓𝐰𝐨 𝐌𝐝'//bot name
global.watermark = "ENJOY WITH ZERO TWO"
global.botname = process.env.botnamw || '𝐙𝐞𝐫𝐨 𝐓𝐰𝐨 𝐌𝐝'
global.ownernma = 'Ikshwaku Pandey' //owner name
global.ownername = process.env.ownername || 'Ikshwaku Pandey' //owner name
global.packname = 'Zero-Two' //sticker package name
global.author = 'Dont Steal' //sticker author name
global.sessionName = process.env.SESSION_ID || 'SESSION-ID'
global.zerotwo = "https://github.com/SamPandey001/Zero-Two-MD" //ur gc link
global.zerotwo2 = "https://github.com/SamPandey001/Zero-Two-MD" //ur gc link2
global.websitex = "https://ZeroTwoMd.tech" //ur website
global.prefa = ['-'] //prefix
global.sp = '✨' //design
module.exports = {
  HEROKU: {
        HEROKU: process.env.HEROKU === undefined ? false : convertToBool(process.env.HEROKU),
        API_KEY: process.env.HEROKU_API_KEY === undefined ? '7328bcf1-4e08-459b-804f-1c35483b9112' : process.env.HEROKU_API_KEY,
        APP_NAME: process.env.HEROKU_APP_NAME === undefined ? 'quiet-harbor-86010' : process.env.HEROKU_APP_NAME
    },
  BRANCH: 'franxx',
  VERSION: process.env.VERSION === undefined ? 'v.1.8' : process.env.VERSION,
 LANG: process.env.LANGUAGE === undefined ? 'en' : process.env.LANGUAGE.toUpperCase(),
 SUPPORT: "120363040838753957@g.us",
  WORKTYPE: process.env.WORKTYPE === undefined ? 'private' : process.env.WORKTYPE
};
global.limitawal = {
    premium: "Infinity", //premium user limit
    free: 40 //free user limit
}
function _0x541c(){var _0x520861=['998048IAMZZZ','./assets/img/zt.jpg','thumb','777904mDNRjN','676040CCHFKt','readFileSync','967962kDYBDh','2833800DPpmXk','1317540Ofobcc','1314yvlPXk','2933gQtPbt'];_0x541c=function(){return _0x520861;};return _0x541c();}function _0x58cd(_0x281a3c,_0x3b6c20){var _0x541cd5=_0x541c();return _0x58cd=function(_0x58cd30,_0x40480a){_0x58cd30=_0x58cd30-0xaf;var _0x2d9baf=_0x541cd5[_0x58cd30];return _0x2d9baf;},_0x58cd(_0x281a3c,_0x3b6c20);}var _0x325c36=_0x58cd;(function(_0x2da43c,_0x5f3f1a){var _0x4e00f1=_0x58cd,_0x4299cb=_0x2da43c();while(!![]){try{var _0x15c880=parseInt(_0x4e00f1(0xb7))/0x1+-parseInt(_0x4e00f1(0xb4))/0x2+-parseInt(_0x4e00f1(0xaf))/0x3+parseInt(_0x4e00f1(0xb0))/0x4+-parseInt(_0x4e00f1(0xb1))/0x5+-parseInt(_0x4e00f1(0xb2))/0x6*(-parseInt(_0x4e00f1(0xb3))/0x7)+-parseInt(_0x4e00f1(0xb8))/0x8;if(_0x15c880===_0x5f3f1a)break;else _0x4299cb['push'](_0x4299cb['shift']());}catch(_0x4ed7c3){_0x4299cb['push'](_0x4299cb['shift']());}}}(_0x541c,0x63b68),global[_0x325c36(0xb6)]=fs[_0x325c36(0xb9)](_0x325c36(0xb5)));

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
	require(file)
})