<h1 align="center">🍭 𝗭𝗲𝗿𝗼 𝗧𝘄𝗼 𝗠𝗗 🍭<br></h1>

<p align="center">

  <img src="https://user-images.githubusercontent.com/104565822/177012232-97866d97-0798-4ca2-9e56-5d0a2413642b.png" alt="21-akeno-wallpaper-Images-of-Akeno-Himejima-Wallpaper-industrious-info" />

</p>


<p align="center"> 

  A Moduler WhatsApp Bot designed for both PM and Groups - To take your boring WhatsApp usage into a whole different level.

   
### Looking for NON MD,go there [NON MD ZERO TWO](https://github.com/Fantox001/Zero-Two)
### How to enable Zero-Two On your number
-   First Open `Github Link Of Zero Two`
-  Click on Fork Button upwards right corner
-  Click on `Scan Qr` button down blew
-  `Open WhatsApp` > `Tap on three dot` > `Linked Devices` > `Link a Device`
-  You'll get `SESSION_ID` in your log number,Keep it safe
-  Click on `Deploy` text in Image down blew 
-  Fill `Config Vars` and SESSION_ID which you acquired before and Tap on `DEPLOY`
-  `Open Heroku` > `choose app` > `Resources` > `Tap on Pencil` and `Turn on Dynos`
-  Bot is Working Now,Enjoy ♥️

- `Thank me later.`
# Main Features of Bot
- First Whatsapp Bot with `Auto Nsfw detection with percentage`
- First whatsapp bot with `NLP AI`
- text to Sticker(like Quotely Telegram Bot)
- Scribd link unlocker
- Torrent Search
- Translator for any language
- Textmaker
- Nsfw
- Group Features
- Chat Features
- Switches for Turning NSFW on and off
- Random Anime
- Anime, Character Search
- Reaction Commands like Poke,punch,bonk
- Mongodb Support
- YouTube,Fb,Twitter,tiktok downloader
- iplookup,imdb,sticker,emojimix, ebinary,dbinary
- And list goes on + adding commands daily + we add requested features too
- Check usage of Commands by prefix+command help eg- -scribd help

  
[![](https://raw.githubusercontent.com/ZeroTwoInc/Media/main/logo/UPPER.png)](https://ZeroTwoMd.tech/#qrcode)
  
[![Deploy](https://raw.githubusercontent.com/ZeroTwoInc/Media/main/logo/MIDDLE.png)](https://heroku.com/deploy?template=https://github.com/Sampandey001/Zero-Two-Md)

[![](https://raw.githubusercontent.com/ZeroTwoInc/Media/main/logo/LOWER.png)](https://youtu.be/rqbeusycfHU)

## Whatsapp Group

<a href="https://chat.whatsapp.com/KK6AVKEwPVJ0aXoWo2cK2g"><img src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

<a href="https://chat.whatsapp.com/Bl2F9UTVU4CBfZU6eVnrbCl"><img src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

## This bot is mainly created on prefix - if you change this buttons will not work


### The Hard Method (Not Recommend)
```js
apt update
apt upgrade
pkg update && pkg upgrade
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
git clone https://github.com/Sampandey001/Zero-Two-Md
cd Zero-Two-Md
npm start
```

### ⚠️ Warning! 
```
 This bot is not a official bot by Whatsapp INC So if you want to use it then feel free to do so.
 Your WhatsApp Number can be banned by Whatsapp as it is not official
 Zero-Two-MD bot is still in the development stage, so there can be few bugs.Feel free to report that to us.
```

## Thanks for Everything 
- [XEON](https://github.com/dgxeon)




## Developers

[![XEON](https://github.com/dgxeon.png?size=80)](https://github.com/dgxeon) | [![Fantox](https://github.com/fantox001.png?size=100)](https://github.com/fantox001) | [![Sam Pandey](https://github.com/sampandey001.png?size=109)](https://github.com/sampandey001) | [![ISSA](https://github.com/issa2001.png?size=80)](https://github.com/issa2001) | [![Prince-Mendiratta](https://github.com/Prince-Mendiratta.png?size=80)](https://github.com/Prince-Mendiratta)
----|----|----|----|----
[XEON](https://wa.me/916909137213) | [Fantox](https://wa.me/918101187835) | [Sam Pandey](https://wa.me/919628516236) | [Issa](https://wa.me/254115175696) | [Prince-Mendiratta](https://wa.me/917838204238)
Base Bot  | Developer, Bug Fixes, Modules |Developer,Bug Fixes,Base, Modules, | Modules, Idea | Modules



## License
This project is protected by `GNU General Public Licence v3.0` license.




## Contributing
Feel free to contribute.

### Disclaimer
This is an open source WhatsApp bot based on Multi Device created by [`@SamPandey001`](https://github.com/SamPandey001) & [`@fantox`](https://github.com/FantoX001) working with [`@adiwajshing/baileys`](https://github.com/adiwajshing/baileys). Do not recode it without notifying the owners otherwise you will be petitioned for fraud & copyright infringement!

## Help
Give a ⭐ to this repo if it helped you.
